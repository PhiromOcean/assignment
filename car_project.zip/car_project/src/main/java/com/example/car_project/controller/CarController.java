package com.example.car_project.controller;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cars")
public class CarController {

    private Map<String, Integer> carMap = new HashMap<>();

    @GetMapping("/name/{name}")
    public String getCarWheels(@PathVariable String name) {
        if (name.equalsIgnoreCase("4-wheel-car")) {
            return getCarsByWheels(4);
        } else if (name.equalsIgnoreCase("2-wheel-car")) {
            return getCarsByWheels(2);
        } else if (name.equalsIgnoreCase("All")) {
            return getAllCars();
        } else if (name.equalsIgnoreCase("Bye")) {
            return "Bye!";
        }

        if (!carMap.containsKey(name)) {
            return String.format("\"%s\" is not on my list. Number of wheels?", name);
        }
        return String.format("\"%s\" has %d wheels.", name, carMap.get(name));
    }

    @PostMapping("/name/{name}")
    public String addCar(@PathVariable String name, @RequestParam int wheels) {
        if (!carMap.containsKey(name)) {
            carMap.put(name, wheels);
            return "Thanks. I updated the information.";
        }
        return String.format("\"%s\" is already on the list.", name);
    }

    private String getCarsByWheels(int wheels) {
        List<String> cars = new ArrayList<>();
        carMap.forEach((name, numWheels) -> {
            if (numWheels == wheels) {
                cars.add(name);
            }
        });
        return String.format("[%d] %s", cars.size(), String.join(", ", cars));
    }

    private String getAllCars() {
        List<String> cars = new ArrayList<>(carMap.keySet());
        return String.format("[%d] %s", cars.size(), String.join(", ", cars));
    }
}
