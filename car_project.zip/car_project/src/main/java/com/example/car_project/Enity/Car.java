package com.example.car_project.Enity;

public class Car {
    private String name;
    private int wheels;

    public Car() {}

    public Car(String name, int wheels) {
        this.name = name;
        this.wheels = wheels;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWheels() {
        return wheels;
    }

    public void setWheels(int wheels) {
        this.wheels = wheels;
    }
}
